export const BASE_URL = 'https://brainn-api-loterias.herokuapp.com/api/v1';
