import styled from 'styled-components';

export const BoxContainer = styled.div`
  display: flex;
  width: 100vw;
  height: 100vh;
  position: absolute;
`;

export const BoxAside = styled.div`
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: left;
  height: 100vh;
  position: absolute;
  top: 0;
  color: #fff;
  padding: 6em 0 6em 6em;
`;

export const DropDown = styled.select`
  height: 2.8em;
  width: 13.5em;
  border: none;
  border-radius: 0.3125em;
  background-color: #fff;
  font-size: 1em;
  font-weight: 500;
  padding-left: 1.44em;
`;

export const Logo = styled.img`
  height: 3.75em;
`;

export const Title = styled.div`
  display: flex;
  align-items: center;
  gap: 1.44em;
`;

export const TitleText = styled.h1`
  font-size: 1.875em;
`;

export const RaffleBox = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr 1fr 1fr;
  width: 65%;
  gap: 2em;
`;

export const RaffleBall = styled.div`
  height: 7em;
  width: 7em;
  border-radius: 50%;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
`;
