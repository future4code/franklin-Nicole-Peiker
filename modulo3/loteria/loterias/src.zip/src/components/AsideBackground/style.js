import styled from 'styled-components';

export const Background = styled.svg`
  position: relative;
  top: 0;
  left: 0;
  height: 100vh;
`;
