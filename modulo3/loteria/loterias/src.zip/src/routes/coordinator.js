export const goToMegaSena = navigate => {
  navigate('/');
};
export const goToQuina = (navigate, id) => {
  navigate('/1');
};
export const goToLotoFacil = navigate => {
  navigate('/2');
};
export const goToLotoMania = navigate => {
  navigate('/3');
};
export const goToTimeMania = (navigate, id) => {
  navigate('/4');
};
export const goToDiaDeSorte = navigate => {
  navigate('/5');
};
export const goToLastPage = navigate => {
  navigate(-1);
};
