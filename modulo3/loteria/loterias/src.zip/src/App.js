import React from 'react';
import Select from './components/Select/Select';

const App = () => {
  return (
    <div>
      <Select />
    </div>
  );
};

export default App;
